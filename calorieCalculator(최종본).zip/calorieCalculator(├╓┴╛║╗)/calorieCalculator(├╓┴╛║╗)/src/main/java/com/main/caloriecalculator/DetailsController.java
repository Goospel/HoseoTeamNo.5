package com.main.caloriecalculator;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DetailsController {

    @FXML
    private Button second_Page_Exit;
    @FXML
    private ListView<String> second_Page_listview;

    // 페이지 닫기
    public void exit_Page(ActionEvent event){
        Stage stage = (Stage) second_Page_Exit.getScene().getWindow();
        stage.close();
    }

    // name2를 설정하고 ListView에 ApiCall.getAll(name2)의 결과를 추가하는 메서드
    public void setListView(String name2) {
        if (second_Page_listview != null) {
            try {
                String apiResult = ApiCall.getAll(name2);
                ObservableList<String> items = FXCollections.observableArrayList();
                String[] lines = apiResult.split("\n");
                for (String line : lines) {
                    items.add(line);
                }


                second_Page_listview.setItems(items);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    public void initialize() {
        // 초기화할 필요가 있는 경우 이곳에 작성
    }
}
