package com.main.caloriecalculator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Controller {

    // 왼쪽 레이아웃 Control들
    @FXML
    private TextField first_1_textField;
    @FXML
    private ListView<String> first_1_listView;
    @FXML
    private Button first_1_button;
    @FXML
    private Button first_ReadMore_button;
    @FXML
    private Button first_confirm_button;

    // 두번째 레이아웃 Control들
    @FXML
    private ListView<String> second_showFoodsIAte_listview;
    @FXML
    private Button second_delete_button;
    @FXML
    private TextArea second_showAllFoods_textArea;

    // 세번째 레이아웃 Controls들
    @FXML
    private ChoiceBox<String> choice_gender;
    @FXML
    private ComboBox<Integer> choice_age;
    private ObservableList<String> ov = FXCollections.observableArrayList();

    private ObservableList<String> secondListViewOv = FXCollections.observableArrayList();
    private double sumCalorie;

    // 추가된 변수
    private String name2;

    @FXML
    private TextField heightTextField;
    @FXML
    private TextField weightTextField;
    @FXML
    private Button compareButton;
    @FXML
    private TextArea resultTextArea;
    @FXML
    private Slider calorieSlider;

    @FXML
    public void initialize() {
        sumCalorie = 0;
        choice_gender.setItems(FXCollections.observableArrayList("남성", "여성"));
        choice_gender.setValue("남성");

        ObservableList<Integer> ageList = FXCollections.observableArrayList();
        for (int i = 0; i <= 100; i++) {
            ageList.add(i);
        }
        choice_age.setItems(ageList);
        choice_age.setPromptText("나이");
        choice_age.setValue(25); // 기본값 설정

        second_showFoodsIAte_listview.setItems(secondListViewOv);
        second_delete_button.setOnAction(e -> pressDeleteButton());

        calorieSlider.setMin(0);
        // 마우스 클릭 이벤트 핸들러 추가
        first_1_listView.setOnMouseClicked(event -> handleMouseClick());

        // ListView의 ObservableList에 리스너 추가
        secondListViewOv.addListener((javafx.collections.ListChangeListener<String>) c -> {
            while (c.next()) {
                if (c.wasAdded() || c.wasRemoved()) {
                    showAllNuts();
                    compareCalories();
                }
            }
        });
    }

    // 마우스 클릭 이벤트 핸들러
    private void handleMouseClick() {
        String selectedItem = first_1_listView.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            name2 = extractFoodName(selectedItem);
        }
    }

    // "-" 이전의 텍스트를 추출하는 함수
    private String extractFoodName(String text) {
        String[] parts = text.split(" - ");
        if (parts.length > 0) {
            return parts[0];
        }
        return "";
    }

    public void pressEnterInTextField() {
        first_1_textField.setOnAction(e -> {
            first_1_button.fire();
            first_1_textField.requestFocus();
        });
    }

    public void pressDeleteButton() {
        String name = second_showFoodsIAte_listview.getSelectionModel().getSelectedItem();

        double calories = extractNumbers(name);
        sumCalorie -= calories;
        System.out.println("sumCalorie = " + sumCalorie);

        secondListViewOv.remove(name);
        ov.remove(name);

        updateCaloriesSlider();
    }

    public void confirmButtonMethod() {
        String name = first_1_listView.getSelectionModel().getSelectedItem();
        if (name != null && !ov.contains(name)) {
            ov.add(name);
            if (!secondListViewOv.contains(name)) {
                double calories = extractNumbers(name);
                sumCalorie += calories;
                System.out.println("sumCalorie = " + sumCalorie);
                secondListViewOv.add(name);
            }
        }

        updateCaloriesSlider();
    }

    @FXML
    public void buttonClicked() {
        try {
            String input = first_1_textField.getText();
            if (!input.isEmpty()) {
                String result = ApiCall.nameAndCalorie(input);
                updateListView(result);
                first_1_textField.clear();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateListView(String apiResult) {
        ObservableList<String> items = FXCollections.observableArrayList();
        String[] lines = apiResult.split("\n");

        for (int i = 0; i < lines.length; i += 2) {
            if (i + 1 < lines.length) {
                String foodName = lines[i].replace("Food Name: ", "");
                String calories = lines[i + 1].replace("Calories: ", "");
                items.add(foodName + " - " + calories + " kcal");
            }
        }
        first_1_listView.setItems(items);
    }

    private double extractNumbers(String input) {
        double result = 0;
        String onlyDigits = input.replaceAll("[^0-9.]", "");

        if (!onlyDigits.isEmpty()) {
            try {
                result = Double.parseDouble(onlyDigits);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public void nextPage() {
        first_ReadMore_button.setOnAction(e -> {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Details.fxml"));
                Parent root = loader.load();

                // 새로운 컨트롤러 인스턴스를 가져와서 name2를 설정
                DetailsController detailsController = loader.getController();
                detailsController.setListView(name2);

                // 새로운 스테이지 생성
                Stage newStage = new Stage();
                newStage.setTitle("자세히보기");
                newStage.setScene(new Scene(root));
                newStage.show();
            } catch (IOException e1) {
                throw new RuntimeException(e1);
            }
        });
    }

    @FXML
    private void compareCalories() {
        String gender = choice_gender.getValue();
        Integer age = choice_age.getValue();
        double height = 0;
        double weight = 0;

        try {
            height = Double.parseDouble(heightTextField.getText().trim());
            weight = Double.parseDouble(weightTextField.getText().trim());
        } catch (NumberFormatException e) {
            e.printStackTrace();
            resultTextArea.setText("키와 몸무게를 올바르게 입력해주세요.");
            return;
        }

        double consumedCalories = sumCalorie;
        double recommendedCalories = calculateRecommendedCalories(gender, age, height, weight);
        double difference = consumedCalories - recommendedCalories;

        String message;
        if (difference > 0) {
            message = String.format("당신의 적정 칼로리는 %.2f kcal 이고, 적정 칼로리보다 %,.2f kcal 더 섭취했습니다.", recommendedCalories, difference);
        } else if (difference < 0) {
            message = String.format("당신의 적정 칼로리는 %.2f kcal 이고, 적정 칼로리보다 %,.2f kcal 덜 섭취했습니다.", recommendedCalories, Math.abs(difference));
        } else {
            message = String.format("당신의 적정 칼로리 %.2f kcal 섭취했습니다.", recommendedCalories);
        }

        System.out.println("Gender: " + gender);
        System.out.println("Age: " + age);
        System.out.println("Height: " + height);
        System.out.println("Weight: " + weight);
        System.out.println("Consumed Calories: " + consumedCalories);
        System.out.println("Recommended Calories: " + recommendedCalories);
        System.out.println("Message: " + message);

        resultTextArea.setWrapText(true);
        resultTextArea.setText(message);

        updateCaloriesSlider();
    }

    private double calculateRecommendedCalories(String gender, int age, double height, double weight) {
        // BMR 계산식
        double bmr;
        if (gender.equals("남성")) {
            bmr = 66.47 + (13.75 * weight) + (5 * height) - (6.76 * age);
        } else {
            bmr = 655.1 + (9.56 * weight) + (1.85 * height) - (4.68 * age);
        }
        return bmr;
    }

    private void updateCaloriesSlider() {
        Integer age = choice_age.getValue();
        if (age == null) {
            return; // age가 null인 경우 아무것도 하지 않음
        }
        double recommendedCalories = calculateRecommendedCalories(choice_gender.getValue(), age, Double.parseDouble(heightTextField.getText().trim()), Double.parseDouble(weightTextField.getText().trim()));
        calorieSlider.setMax(sumCalorie > recommendedCalories ? sumCalorie : recommendedCalories);
        calorieSlider.setValue(sumCalorie);
    }

    public void showAllNuts() {
        // 영양소 합계를 저장할 맵 생성
        Map<String, Double> nutrientsTotal = new HashMap<>();
        nutrientsTotal.put("열량", 0.0);
        nutrientsTotal.put("탄수화물", 0.0);
        nutrientsTotal.put("단백질", 0.0);
        nutrientsTotal.put("지방", 0.0);

        // second_showFoodsIAte_listview에서 모든 음식 이름을 가져옴
        for (String food : second_showFoodsIAte_listview.getItems()) {
            String foodName = extractFoodName(food);

            // ApiCall.getEssential() 호출하여 영양소 정보 가져옴
            try {
                String essentialInfo = ApiCall.getEssential(foodName);
                Map<String, Double> foodNutrients = parseEssentialInfo(essentialInfo);

                // 영양소 합산
                for (String nutrient : foodNutrients.keySet()) {
                    nutrientsTotal.put(nutrient, nutrientsTotal.get(nutrient) + foodNutrients.get(nutrient));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 결과를 second_showAllFoods_textArea에 표시
        StringBuilder result = new StringBuilder();
        result.append("총 영양소 합계:\n");
        result.append("열량 (kcal): ").append(nutrientsTotal.get("열량")).append("\n");
        result.append("탄수화물 (g): ").append(nutrientsTotal.get("탄수화물")).append("\n");
        result.append("단백질 (g): ").append(nutrientsTotal.get("단백질")).append("\n");
        result.append("지방 (g): ").append(nutrientsTotal.get("지방")).append("\n");

        second_showAllFoods_textArea.setWrapText(true);
        second_showAllFoods_textArea.setText(result.toString());
    }

    private Map<String, Double> parseEssentialInfo(String essentialInfo) {
        Map<String, Double> nutrients = new HashMap<>();
        String[] lines = essentialInfo.split("\n");

        for (String line : lines) {
            if (line.startsWith("열량 (kcal): ")) {
                nutrients.put("열량", Double.parseDouble(line.replace("열량 (kcal): ", "").trim()));
            } else if (line.startsWith("탄수화물 (g): ")) {
                nutrients.put("탄수화물", Double.parseDouble(line.replace("탄수화물 (g): ", "").trim()));
            } else if (line.startsWith("단백질 (g): ")) {
                nutrients.put("단백질", Double.parseDouble(line.replace("단백질 (g): ", "").trim()));
            } else if (line.startsWith("지방 (g): ")) {
                nutrients.put("지방", Double.parseDouble(line.replace("지방 (g): ", "").trim()));
            }
        }

        return nutrients;
    }
}
