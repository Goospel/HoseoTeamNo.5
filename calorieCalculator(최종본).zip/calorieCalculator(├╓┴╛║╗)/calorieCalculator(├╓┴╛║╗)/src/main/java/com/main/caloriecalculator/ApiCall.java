package com.main.caloriecalculator;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ApiCall {
    /// 1. 기본 URL 설정
    /// 'StringBuilder' 객체를 생성하고, API호출을 위한 기본 URL을 설정합니다.
    /// 'StringBuilder'는 문자열을 조작하기에 효율적인 클래스입니다.(가변객체이기 때문)
    /// 2. 서비스 키 추가
    private static String serviceKey = "nY9BAl1gzMofnhOR0y7cmt8ZXqnb2k9zZd%2FyFTqxi7x79dlrzBUNR9CDQfiZRM5s4c5Zw%2FseYWcUAKzskxGa8Q%3D%3D";

    private static String fetchDataFromApi(String keyword) throws IOException, ParseException {
        StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1471000/FoodNtrIrdntInfoService1/getFoodNtrItdntList1");
        /// 'serviceKey'는 API인증을 위해 필요한 키입니다. 이미 인코딩된 상태로 제공됩니다. <?> 인코딩이 뭐지 </?>
        /// 'urlBuilder.append'를 사용하여 기본 URL뒤에 서비스 키를 추가합니다.
        /// 'URLEncoder.encode'메서드는 URL에 특수 문자가 포함될 경우 이를 인코딩해줍니다. 여기서는 '"serviceKey"'라는 문자열을 UTF-8로 인코딩하여 URL에 추가합니다.
        /// <?> 'URLEncode.ecnode'메서드는 URL에 특수문자가 포함될 경울 이를 인코딩한다는데...좀더 자세히 알고싶네.
        /// "serviceKey"라는 문자열에는 특수문자가 없는데 그래도 인코딩을 해야되는건가? </?>
        urlBuilder.append("?" + URLEncoder.encode("serviceKey", "UTF-8") + "=" + serviceKey);
        urlBuilder.append("&" + URLEncoder.encode("desc_kor", "UTF-8") + "=" + URLEncoder.encode(keyword, "UTF-8"));
        urlBuilder.append("&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8"));
        urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "=" + URLEncoder.encode("100", "UTF-8"));
        urlBuilder.append("&" + URLEncoder.encode("type", "UTF-8") + "=" + URLEncoder.encode("json", "UTF-8"));


        /// 1. URL 객체 생성
        /// 'urlBuilder'객체에 의해 동적으로 생성된 URL문자열을 사용하여 'URL' 객체를 생성합니다.
        /// 'URL' 클래스는 인터넷 리소스의 주소를 나타내는 자바의 표준 클래스입니다.
        URL url = new URL(urlBuilder.toString());
        /// 2. HttpURLConnection 객체 생성
        /// 'url.openConnection()' 매서드를 호출하여 'HttpURLConnection' 객체를 생성합니다.
        /// 'HttpURLConnection' 클래스는 HTTP프로토콜을 사용하여 통신하기 위한 클래스입니다.
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        /// 3, 요청 메서드 설정
        /// 'setRequestMethod'메서드를 사용하여 HTTP요청 메서드를 설정합니다.
        /// 여기서는 데이터를 요청하는 GET메서드를 사용합니다.
        conn.setRequestMethod("GET");
        /// 4. 요청 속성 성질
        /// 'setRequestProperty'메서드를 사용하여 HTTP 요청 헤더를 설정합니다.
        /// "Content-type"헤더를 "application/json"으로 설정하여 서버에 Json 형식의 응답을 요청합니다.
        conn.setRequestProperty("Content-type", "application/json");

        /// 5. 응답 코드 확인
        /// 'getResponseCode'메서드를 호출하여 서버로부터 받은 HTTP응답 코드르 확인합니다.
        /// 응답 코드는 요청의 성공 또는 실패를 나타내며, 일반적으로 200~299 범위는 성공, 400~499 범위는 클라이언트 오류, 500~ 599범위는 서버 오류를 의미합니다.
        int responseCode = conn.getResponseCode();
        /// 6. 응답 데이터읽기
        /// 응답 코드에 따라 입력 스트림을 결정합니다.
        /// - 응답 코드가 200 ~ 300 범위(성공)인 경우, 'conn.getInputStream()'을 사용하여 입력스트림을 생성합니다.
        /// - 그렇지 않은 경우(오류), 'conn.getErrorStream()'을 사용하여 오류 스트림을 생성합니다.
        BufferedReader rd;
        if (responseCode >= 200 && responseCode <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        /// 7. 응답 데이터를 문자열로 변환
        /// 'BufferedReader'를 사용하여 응답 데이터를 한 줄씩 읽어옵니다.
        /// 읽어온 데이터를 'StringBuilder'에 추가하여 전체 응답을 하나의 문자열로 만듭니다.
        /// 모든 데이터를 읽은 후 'BufferedReader'를 닫고, 'HttpRULConnection' 객체를 해제합니다.
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line);
        }
        rd.close();
        conn.disconnect();

        return sb.toString();//return값 String
    }//사용시 참고하세여 ** 받는 인자 :검색할 식품이름 / return 문자열로 반환 json형식을 되어있음 파싱해서 정보추출가능

    public static String nameAndCalorie(String keyword) {
        // 1. 결과를 저장할 StringBuilder 객체 생성
        StringBuilder result = new StringBuilder();
        try {
            // 2. API로부터 데이터를 가져옴
            String response = fetchDataFromApi(keyword);

            // 3. JSON 파서를 생성하여 응답 문자열을 JSON 객체로 파싱
            JSONParser parser = new JSONParser();
            JSONObject jsonObject = (JSONObject) parser.parse(response);

            // 4. 최상위 JSON 객체에서 "body" 객체를 가져옴
            JSONObject body = (JSONObject) jsonObject.get("body");

            // 5. body 객체가 null이 아닌 경우, "items" 배열을 가져옴
            if (body != null) {
                JSONArray items = (JSONArray) body.get("items");

                // 6. 식품 이름과 칼로리를 저장할 HashMap 객체 생성
                HashMap<String, Double> foodCaloriesMap = new HashMap<>();

                // 7. items 배열을 반복하여 각 아이템을 처리
                for (Object item : items) {
                    JSONObject itemObject = (JSONObject) item;

                    // 8. 각 아이템에서 식품 이름(descKor)과 칼로리(nutrCont1)를 가져옴
                    String descKor = (String) itemObject.get("DESC_KOR");
                    Double nutrCont1 = Double.valueOf((String) itemObject.get("NUTR_CONT1"));

                    // 9. 식품 이름에 키워드가 포함되어 있는지 확인하고, 포함되어 있으면 HashMap에 추가
                    if (descKor.contains(keyword)) {
                        if (!foodCaloriesMap.containsKey(descKor)) {
                            foodCaloriesMap.put(descKor, nutrCont1);
                        }
                    }
                }

                // 10. HashMap을 반복하여 결과 문자열을 생성
                for (Map.Entry<String, Double> entry : foodCaloriesMap.entrySet()) {
                    result.append("Food Name: ").append(entry.getKey()).append("\n");
                    result.append("Calories: ").append(entry.getValue()).append("\n");
                }
            } else {
                // 11. body 객체가 null인 경우, "No data found." 메시지 추가
                result.append("No data found.\n");
            }
        } catch (IOException | ParseException e) {
            // 12. 예외 발생 시, 예외 메시지를 결과 문자열에 추가
            e.printStackTrace();
            result.append("An error occurred: ").append(e.getMessage()).append("\n");
        }
        // 13. 결과 문자열 반환
        return result.toString();
    }////사용시 참고하세여 ** 받는 인자 :검색할 식품이름 / return 파싱해서 식품이름과 칼로리랑 우리가 보기 편한 형태로 나옴
    //Food Name: Apple
    //Calories: 52.0
    //Food Name: Banana
    //Calories: 89.0

    public static String getAll(String keyword) {
        StringBuilder result = new StringBuilder(); // 1. 결과를 저장할 StringBuilder 객체 생성
        try {
            String response = fetchDataFromApi(keyword); // 2. API로부터 데이터를 가져옴
            JSONParser parser = new JSONParser(); // 3. JSON 파서를 생성하여 응답 문자열을 JSON 객체로 파싱
            JSONObject jsonObject = (JSONObject) parser.parse(response);
            JSONObject body = (JSONObject) jsonObject.get("body"); // 4. 최상위 JSON 객체에서 "body" 객체를 가져옴
            if (body != null) {
                JSONArray items = (JSONArray) body.get("items"); // 5. body 객체가 null이 아닌 경우, "items" 배열을 가져옴
                JSONObject latestItem = null; // 6. 최신 데이터를 저장할 객체와 구축 년도를 저장할 변수 생성
                int latestYear = 0;

                for (Object item : items) { // 7. items 배열을 반복하여 각 아이템을 처리
                    JSONObject itemObject = (JSONObject) item;
                    String foodName = (String) itemObject.get("DESC_KOR");
                    int year = Integer.parseInt((String) itemObject.get("BGN_YEAR"));

                    if (foodName.equals(keyword)) { // 8. 같은 식품 이름이 있으면 구축 년도가 높은 데이터를 저장
                        if (latestItem == null || year > latestYear) {
                            latestItem = itemObject;
                            latestYear = year;
                        }
                    }
                }

                if (latestItem != null) { // 9. 최신 데이터들을 result 문자열에 추가
                    result.append("식품이름: ").append(latestItem.get("DESC_KOR")).append("\n");
                    result.append("1회제공량 (g): ").append(latestItem.get("SERVING_WT")).append("\n");
                    result.append("열량 (kcal): ").append(latestItem.get("NUTR_CONT1")).append("\n");
                    result.append("탄수화물 (g): ").append(latestItem.get("NUTR_CONT2")).append("\n");
                    result.append("단백질 (g): ").append(latestItem.get("NUTR_CONT3")).append("\n");
                    result.append("지방 (g): ").append(latestItem.get("NUTR_CONT4")).append("\n");
                    result.append("당류 (g): ").append(latestItem.get("NUTR_CONT5")).append("\n");
                    result.append("나트륨 (mg): ").append(latestItem.get("NUTR_CONT6")).append("\n");
                    result.append("콜레스테롤 (mg): ").append(latestItem.get("NUTR_CONT7")).append("\n");
                    result.append("포화지방산 (g): ").append(latestItem.get("NUTR_CONT8")).append("\n");
                    result.append("트랜스지방산 (g): ").append(latestItem.get("NUTR_CONT9")).append("\n");
                    result.append("구축년도: ").append(latestItem.get("BGN_YEAR")).append("\n");
                    result.append("가공업체: ").append(latestItem.get("ANIMAL_PLANT")).append("\n\n");
                } else {
                    result.append("No data found.\n"); // 10. 최신 데이터가 없는 경우, "No data found." 메시지 추가
                }
            } else {
                result.append("No data found.\n"); // 11. body 객체가 null인 경우, "No data found." 메시지 추가
            }
        } catch (IOException | ParseException e) { // 12. 예외 발생 시, 예외 메시지를 결과 문자열에 추가
            e.printStackTrace();
            result.append("An error occurred: ").append(e.getMessage()).append("\n");
        }
        return result.toString(); // 13. 결과 문자열 반환
    }////사용시 참고하세여 ** 받는 인자 :검색할 식품이름 / return 파싱해서 item 전부


    public static String getEssential(String keyword) {
        StringBuilder result = new  StringBuilder(); // 1. 결과를 저장할 StringBuilder 객체 생성
        try {
            String response = fetchDataFromApi(keyword); // 2. API로부터 데이터를 가져옴
            JSONParser parser = new JSONParser(); // 3. JSON 파서를 생성하여 응답 문자열을 JSON 객체로 파싱
            JSONObject jsonObject = (JSONObject) parser.parse(response);
            JSONObject body = (JSONObject) jsonObject.get("body"); // 4. 최상위 JSON 객체에서 "body" 객체를 가져옴
            if (body != null) {
                JSONArray items = (JSONArray) body.get("items"); // 5. body 객체가 null이 아닌 경우, "items" 배열을 가져옴
                JSONObject latestItem = null; // 6. 최신 데이터를 저장할 객체와 구축 년도를 저장할 변수 생성
                int latestYear = 0;

                for (Object item : items) { // 7. items 배열을 반복하여 각 아이템을 처리
                    JSONObject itemObject = (JSONObject) item;
                    String foodName = (String) itemObject.get("DESC_KOR");
                    int year = Integer.parseInt((String) itemObject.get("BGN_YEAR"));

                    if (foodName.equals(keyword)) { // 8. 같은 식품 이름이 있으면 구축 년도가 높은 데이터를 저장
                        if (latestItem == null || year > latestYear) {
                            latestItem = itemObject;
                            latestYear = year;
                        }
                    }
                }

                if (latestItem != null) { // 9. 최신 데이터들을 result 문자열에 추가
                    result.append("식품이름: ").append(latestItem.get("DESC_KOR")).append("\n");
                    result.append("열량 (kcal): ").append(latestItem.get("NUTR_CONT1")).append("\n");
                    result.append("탄수화물 (g): ").append(latestItem.get("NUTR_CONT2")).append("\n");
                    result.append("단백질 (g): ").append(latestItem.get("NUTR_CONT3")).append("\n");
                    result.append("지방 (g): ").append(latestItem.get("NUTR_CONT4")).append("\n\n");
                } else {
                    result.append("No data found.\n"); // 10. 최신 데이터가 없는 경우, "No data found." 메시지 추가
                }
            } else {
                result.append("No data found.\n"); // 11. body 객체가 null인 경우, "No data found." 메시지 추가
            }
        } catch (IOException | ParseException e) { // 12. 예외 발생 시, 예외 메시지를 결과 문자열에 추가
            e.printStackTrace();
            result.append("An error occurred: ").append(e.getMessage()).append("\n");
        }
        return result.toString(); // 13. 결과 문자열 반환
    }
}


